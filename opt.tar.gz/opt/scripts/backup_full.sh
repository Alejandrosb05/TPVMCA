#!/bin/bash

FECHA=$(date +"%Y%m%d")
HORA=$(date +"%H%M%S")
FILE=backup_${FECHA}_${HORA}

if [ "$1" == "-help" ] ||  [ "$2" == "-help" ]; then
	echo "Esto es un script para realizar un backup de un archivo."
	echo "Primero debe pasar el origen y luego el destino, el scrip crea el archivo."
	echo "Usted debe crear el origen y el destino sino el scipt se detendra."
	exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ] || [ ! -d "$DESTINO" ]; then
	echo "Error,El origen o el destino no existen o no se encuentras disponibles para ser usados"
	exit 2
fi	

ULT_DOC=$(basename "$ORIGEN")
FILE="${ULT_DOC}_bkp_${FECHA}.tar.gz"
tar -czf "${DESTINO}/${FILE}" "$ORIGEN"
echo "El backup de $ORIGEN se a creado sin problemas."

